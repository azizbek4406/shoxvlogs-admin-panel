export const environment = {
  production: true,
  api: 'https://api.shoxvlogs.uz',
  Nom: 'Shox vlogs'
};
