import { Fayl } from "./fayil";

export interface Yangilik {
    id: number,
    mant: String,
    tuliqMalumot: String,
    image: Fayl,
    onlineYangilik: String
}