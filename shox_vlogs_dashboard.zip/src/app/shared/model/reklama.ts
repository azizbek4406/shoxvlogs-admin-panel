export interface Reklama {
    id: number;
    image: String
}