export interface Fayl {
    id: number;
    nomi: string;
    localDate: string 
}