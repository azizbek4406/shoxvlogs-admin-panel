import { Fayl } from "./fayil";

export interface ShowBiznes {
    id: number,
    mant: String,
    tuliqMalumot: String,
    image: Fayl
}